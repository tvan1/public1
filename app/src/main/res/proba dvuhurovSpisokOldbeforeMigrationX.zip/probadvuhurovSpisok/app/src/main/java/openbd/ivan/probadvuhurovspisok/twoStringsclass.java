package openbd.ivan.probadvuhurovspisok;

public class twoStringsclass
{

    private final String group;
    private final String text;


    public twoStringsclass(String group, String text) {
        this.group = group;
        this.text = text;
    }


    public void setText(String text)
    {
        text = text;
    }
    public void setGroup(String group)
    {
        group = group;
    }
    public String getText() {
        return text;
    }

    public String getGroup() {
        return group;
    }
}
